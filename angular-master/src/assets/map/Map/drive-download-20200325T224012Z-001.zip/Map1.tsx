<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="Map1" tilewidth="16" tileheight="16" tilecount="3492" columns="36">
 <image source="../Map/spritesheet.png" width="576" height="1552"/>
 <tile id="9">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="259">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="653">
  <properties>
   <property name="mapChanger" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="936">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="937">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="938">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
